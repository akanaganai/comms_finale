ooops your files are encrypted

don't start sweating were the good guys just teaching a lesson today,

we've been here for a while now and copied everything we've found interesting, 

$500 worth of Monero : 87odMENmbxyVzWt6cTgxtWbrWqwG9GBCn6AHKKYyAK7P1WAwWtnfZNe6hpG1bZgehZ8if4Eoh3UfjjeEXUWNK6VUG5oc6T6

your smart enough to figure out how to buy it I'm sure , thats the address...

I got lazy to put a visible timer for your guys but lets just say if you get to 47 hours you probably should just replace all your IT infrastructure or look for new jobs

2 x 256-bit encryption keys were used, that means means nothing to you but thats why its simpler if you just pay 

Once you've paid you'll recieve your decryption key within 12hrs of confirmation of the payment

thank you for your time 

-deadsec 















***********************************************************************************************************************************
***********************************************************************************************************************************
 Decryption instructions : 

so either reinstall windows and tell it to keep your passwords or move your encrypted files to another device to decrypt cause trust your computer is currently unusable 

then get your decryption key, save it into a text file in the same directory as the enjoyable.exe and run it. 

please note this will only decrypt files within the same folder so place all encrypted files in a folder (say folder 2), which is within the enjoyable.exe folder (say folder 1 )...... orrrr if you reinstall your windows

move your enjoyable to C:\ and run it from there remember to include the password file in the same folder, save it as windows_update_aug-nov23.txt . 






